---
name: Modern Mediterranean Renovation
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f4'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#54433d'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#86736c'
  outline-variant: '#d9c2b9'
  surface-tint: '#914b2c'
  primary: '#8e492a'
  on-primary: '#ffffff'
  primary-container: '#ac6140'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb597'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2dfde'
  on-secondary-container: '#636262'
  tertiary: '#5b5c5c'
  on-tertiary: '#ffffff'
  tertiary-container: '#737575'
  on-tertiary-container: '#fcfcfc'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcd'
  primary-fixed-dim: '#ffb597'
  on-primary-fixed: '#360f00'
  on-primary-fixed-variant: '#733517'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1b1b1c'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 56px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: DM Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: DM Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: DM Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: 0.1em
  button:
    fontFamily: DM Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: '1.0'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1200px
  gutter: 24px
  section-padding-desktop: 120px
  section-padding-mobile: 64px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style
The design system is anchored in the concept of "Luminous Heritage." It bridges the gap between traditional Spanish craftsmanship and modern architectural precision. The brand personality is professional, established, and deeply rooted in the local context of Huesca, yet it utilizes a clean, minimalist aesthetic to project a forward-thinking approach to home reform.

The visual style leans into **Minimalism** with a **Tactile** warmth. It prioritizes generous whitespace to evoke a sense of clarity and organization—essential traits for a renovation company. Imagery should be high-resolution, featuring natural light, clean lines, and the physical textures of stone, wood, and clay. The emotional response should be one of "certainty"—the user must feel that their home is in safe, expert hands.

## Colors
This design system utilizes a palette inspired by natural building materials and the Huesca landscape. 

*   **Terracotta (#C0714F):** The primary brand signature. It is used for calls to action, highlights, and key brand moments to provide warmth and local character.
*   **Neutral Base (#FFFFFF & #F9F9F9):** Surfaces are predominantly white or off-white to maintain the "luminous" quality. #F9F9F9 is used for subtle section backgrounds to create a clear visual hierarchy between content blocks.
*   **Dark Gray (#1F1F1F):** Used for typography and iconography to ensure maximum readability and a grounded, professional feel.
*   **Gray Muted (#6B6B6B):** Reserved for secondary information and labels to prevent visual clutter.

## Typography
The typography strategy pairings serif and sans-serif fonts to create a "Professional-Elegant" contrast.

**Playfair Display** is used for all headlines. Its high-contrast strokes and traditional serifs suggest an established, authoritative company with a respect for architectural history. It should always be used with tight letter-spacing in larger sizes.

**DM Sans** is the functional workhorse. It provides a clean, geometric counterpoint to the serif headers. Its low-contrast and open apertures ensure that technical information about renovations is easily digestible. Use `label-caps` for small descriptors above headings or for trust badges to add a modern, editorial touch.

## Layout & Spacing
The design system follows a **Fixed Grid** philosophy for desktop to maintain a premium, curated appearance. 

*   **Grid:** A 12-column grid with a 24px gutter. On mobile, this collapses to a 4-column grid with 16px side margins.
*   **Vertical Rhythm:** Large vertical gaps (`section-padding-desktop`) between major content blocks ensure the "luminous" and "airy" feel. 
*   **Consistency:** All internal component spacing is based on an 8px (0.5rem) scale. Card interiors should use `stack-lg` (32px) padding to ensure content doesn't feel cramped, emphasizing the high-end nature of the services.

## Elevation & Depth
Depth in this design system is achieved through **Tonal Layers** and **Ambient Shadows**. We avoid heavy shadows in favor of a "flat-but-lifted" look.

*   **Level 0 (Base):** White (#FFFFFF) for the main page background.
*   **Level 1 (Subtle Lift):** Off-white (#F9F9F9) for section backgrounds and secondary cards.
*   **Level 2 (Active Elements):** Cards and CTAs use a very soft, diffused shadow (15% opacity of the primary color or dark gray) with a large blur radius (20px-30px) to suggest they are floating slightly above the luminous base.
*   **Outlines:** Use 1px borders in `border-light` (#E5E5E5) for form fields and list items to maintain structure without adding visual weight.

## Shapes
The shape language is **Rounded**, strike a balance between friendly and architectural.

A base radius of 0.5rem (8px) is applied to buttons, input fields, and small cards. For larger service cards or featured imagery containers, use `rounded-lg` (16px) or `rounded-xl` (24px) to soften the layout and make the photography feel more integrated. This softness contrasts beautifully with the sharp serifs of the Playfair Display typography.

## Components
Consistent component execution is vital for conveying reliability.

*   **Buttons:** Primary buttons use the Terracotta fill with white text. They should have ample horizontal padding (32px) and no border. Secondary buttons use a `border-light` outline with Terracotta text.
*   **Service Cards:** These are the centerpiece. Use a vertical stack: high-quality image (top), `headline-sm` title, and a brief `body-md` description. The card should have a white background and a subtle elevation shadow on hover.
*   **Horizontal Process Timeline:** A thin 1px horizontal line in Terracotta connecting circular nodes. Each node represents a phase (e.g., "Consultation," "Design," "Build"). Use `label-caps` for the step titles.
*   **Trust Badges:** Small, monochromatic icons (Dark Gray) paired with `label-caps` text. These should be grouped in a clean row, often placed just below the Hero CTA or in the Footer.
*   **High-Contrast CTAs:** Full-width sections using a Terracotta background with White text or a Dark Gray background with Terracotta accents to create a hard break in the luminous scroll and drive conversion.
*   **Input Fields:** Clean, white backgrounds with `border-light` outlines that transition to Terracotta on focus. Labels should use `body-md` in Dark Gray.