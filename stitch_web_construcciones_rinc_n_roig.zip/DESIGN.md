---
name: Aragon Industrial Modern
colors:
  surface: '#fdf8f8'
  surface-dim: '#ddd9d8'
  surface-bright: '#fdf8f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3f2'
  surface-container: '#f1edec'
  surface-container-high: '#ebe7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#444748'
  inverse-surface: '#313030'
  inverse-on-surface: '#f4f0ef'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#181919'
  on-primary: '#ffffff'
  primary-container: '#2d2d2d'
  on-primary-container: '#959494'
  inverse-primary: '#c8c6c6'
  secondary: '#9a4600'
  on-secondary: '#ffffff'
  secondary-container: '#ff842d'
  on-secondary-container: '#632b00'
  tertiary: '#161919'
  on-tertiary: '#ffffff'
  tertiary-container: '#2b2d2d'
  on-tertiary-container: '#939494'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e4e2e1'
  primary-fixed-dim: '#c8c6c6'
  on-primary-fixed: '#1b1c1c'
  on-primary-fixed-variant: '#474747'
  secondary-fixed: '#ffdbc9'
  secondary-fixed-dim: '#ffb68c'
  on-secondary-fixed: '#321200'
  on-secondary-fixed-variant: '#753400'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#fdf8f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  headline-xl:
    fontFamily: Metropolis
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Metropolis
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Metropolis
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
  headline-md:
    fontFamily: Metropolis
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-bold:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
---

## Brand & Style

The design system is built to project authority, precision, and the rugged reliability associated with high-end construction in the Huesca region. The aesthetic is **Modern Industrial**, characterized by a serious and trustworthy tone that mirrors the architectural integrity of professional renovation work.

The system utilizes a high-contrast palette to ensure absolute clarity. It avoids decorative trends in favor of structural honesty, using sharp edges and a disciplined grid to evoke the feeling of blueprints and technical drawings. The target audience—ranging from private homeowners to commercial developers—should feel a sense of security and institutional strength when interacting with the interface.

## Colors

The color strategy is rooted in the materials of the trade. **Anthracite Gray (#2D2D2D)** serves as the foundation, used for structural elements, headers, and primary text to establish a grounded, heavy-duty feel. **Construction Orange (#E8731A)** is used exclusively for high-priority actions, notifications, and critical UI pathing, ensuring high visibility against the darker tones.

**Pure White (#FFFFFF)** is used for large expanses of background to keep the layout feeling modern and clean, preventing the heavy gray from becoming oppressive. Secondary neutrals are used for borders and subtle backgrounds to maintain the sharp, technical aesthetic without sacrificing legibility.

## Typography

This design system employs a dual-sans-serif pairing to achieve a balance of technical precision and readability. 

**Metropolis** is used for headings. Its geometric construction and heavy weights provide the "authoritative" presence required for a construction leader. Headings should utilize tight letter-spacing and bold weights to feel architectural.

**Hanken Grotesk** is used for all body copy and UI labels. It offers exceptional legibility in professional contexts. For functional labels and small metadata, use the uppercase style with increased letter-spacing to mimic industrial stencil markings and professional blueprints.

## Layout & Spacing

The layout philosophy follows a **Fixed Grid** model on desktop to maintain a controlled, structured environment that reflects architectural planning. 

- **Grid:** A 12-column grid system is used for desktop (1024px+), shifting to a 4-column grid for mobile devices.
- **Rhythm:** An 8px base unit drives all spacing. Gutters are fixed at 24px to ensure distinct separation between project cards and service blocks.
- **Alignment:** All elements must align to the grid edges. No "soft" floating elements are permitted; every component should feel like it is part of a larger, rigid structure. 
- **Margins:** Large outer margins on desktop create a "gallery" effect for high-resolution project photography.

## Elevation & Depth

This design system rejects soft shadows and organic depth. Instead, it uses **Bold Borders** and **Tonal Layers** to create hierarchy.

1.  **Strict Flatness:** Avoid drop shadows entirely. Depth is achieved through the use of high-contrast color blocks (e.g., Anthracite elements sitting on Pure White backgrounds).
2.  **Structural Outlines:** Use 1px or 2px solid strokes in Anthracite or Light Gray to define boundaries. 
3.  **Surface Tiers:** Use the Medium-Gray for "sunken" interactive areas like input fields, and Pure White for "raised" interactive areas like cards.
4.  **Interaction Depth:** On hover, instead of lifting an element with a shadow, change the background color or increase the border weight to maintain the "solid" feel of the UI.

## Shapes

The shape language is strictly **Sharp (0px radius)**. 

Every component—including buttons, input fields, cards, and image containers—must feature 90-degree corners. This evokes the precision of masonry, steelwork, and technical drawing. There are no exceptions for rounded corners in this design system, as the sharp aesthetic is the primary driver of the "serious and trustworthy" brand personality.

## Components

### Buttons
- **Primary:** Solid Anthracite (#2D2D2D) with White text for standard actions. 
- **CTA:** Solid Orange (#E8731A) with White text for high-conversion actions like "Request a Quote."
- **Ghost:** Transparent background with a 2px Anthracite border.
- **Style:** All buttons are rectangular with no corner radius and use uppercase labels.

### Input Fields
- **Default:** White background with a 1px Dark-Gray border.
- **Active/Focus:** The border weight increases to 2px Orange.
- **Labels:** Always positioned above the field in bold, uppercase Hanken Grotesk.

### Cards (Project/Service)
- **Structure:** No shadows. Use a 1px Light-Gray border to define the card area on white backgrounds.
- **Imagery:** Full-bleed images at the top of the card with zero padding to the edges.
- **Content:** Text should be padded significantly (24px or 32px) to maintain a premium feel.

### Specialized Components
- **Project Progress Tracker:** A linear, stepped progress bar using Orange for completed stages and Dark Gray for upcoming stages, appearing on client-facing renovation dashboards.
- **Comparison Slider:** A vertical split-line tool for "Before & After" renovation showcases, utilizing a sharp-edged Orange handle.
- **Data Tables:** High-density, border-only tables for material specifications and budgeting.